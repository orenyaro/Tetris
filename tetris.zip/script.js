// טטריס פשוט ב-HTML5/Canvas, מותאם למובייל
(() => {
  const canvas = document.getElementById('board');
  const ctx = canvas.getContext('2d');
  const scoreEl = document.getElementById('score');
  const linesEl = document.getElementById('lines');
  const levelEl = document.getElementById('level');
  const btnL = document.getElementById('left');
  const btnR = document.getElementById('right');
  const btnRot = document.getElementById('rotate');
  const btnD = document.getElementById('down');
  const btnPause = document.getElementById('pause');
  const btnRestart = document.getElementById('restart');

  const COLS = 10, ROWS = 20, BLOCK = 24;
  // Canvas logical size
  canvas.width = COLS * BLOCK;
  canvas.height = ROWS * BLOCK;

  // צבעים עבור צורות
  const COLORS = {
    I:'#00f0f0', J:'#0000f0', L:'#f0a000', O:'#f0f000',
    S:'#00f000', T:'#a000f0', Z:'#f00000', X:'#222' // X = ריק
  };

  // מטריצות של חלקים
  const SHAPES = {
    I: [[1,1,1,1]],
    J: [[1,0,0],[1,1,1]],
    L: [[0,0,1],[1,1,1]],
    O: [[1,1],[1,1]],
    S: [[0,1,1],[1,1,0]],
    T: [[0,1,0],[1,1,1]],
    Z: [[1,1,0],[0,1,1]]
  };
  const TYPES = Object.keys(SHAPES);

  const emptyRow = () => Array(COLS).fill('X');
  let grid = Array.from({length: ROWS}, emptyRow);

  function drawBlock(x,y,color) {
    ctx.fillStyle = color;
    ctx.fillRect(x*BLOCK, y*BLOCK, BLOCK-1, BLOCK-1);
  }

  function drawGrid() {
    ctx.fillStyle = '#111';
    ctx.fillRect(0,0,canvas.width, canvas.height);
    for (let y=0;y<ROWS;y++) {
      for (let x=0;x<COLS;x++) {
        if (grid[y][x] !== 'X') drawBlock(x,y,COLORS[grid[y][x]]);
      }
    }
  }

  function randomPiece() {
    const t = TYPES[Math.floor(Math.random()*TYPES.length)];
    return {
      type: t,
      shape: SHAPES[t].map(r=>r.slice()),
      x: 3,
      y: 0
    };
  }

  function rotate(mat) {
    const N = mat.length;
    const M = mat[0].length;
    const res = Array.from({length:M}, () => Array(N).fill(0));
    for (let y=0;y<N;y++) for (let x=0;x<M;x++) res[x][N-1-y] = mat[y][x];
    return res;
  }

  function collides(p, offX=0, offY=0, testShape=null) {
    const sh = testShape || p.shape;
    for (let y=0;y<sh.length;y++) for (let x=0;x<sh[y].length;x++) {
      if (!sh[y][x]) continue;
      const nx = p.x + x + offX;
      const ny = p.y + y + offY;
      if (nx < 0 || nx >= COLS || ny >= ROWS) return true;
      if (ny >=0 && grid[ny][nx] !== 'X') return true;
    }
    return false;
  }

  function merge(p) {
    for (let y=0;y<p.shape.length;y++) for (let x=0;x<p.shape[y].length;x++) {
      if (p.shape[y][x]) {
        const gy = p.y + y;
        if (gy>=0) grid[gy][p.x + x] = p.type;
      }
    }
  }

  function clearLines() {
    let cleared = 0;
    grid = grid.filter(row => !row.every(c => c !== 'X'));
    const missing = ROWS - grid.length;
    for (let i=0;i<missing;i++) grid.unshift(emptyRow());
    cleared = missing;
    return cleared;
  }

  let piece = randomPiece();
  let dropCounter = 0;
  let last = performance.now();
  let score = 0, lines = 0, level = 1;
  let paused = false;
  function speedMs() { return Math.max(1000 - (level-1)*80, 120); }

  function update(now) {
    const dt = now - last;
    last = now;
    if (!paused) {
      dropCounter += dt;
      if (dropCounter > speedMs()) {
        drop();
        dropCounter = 0;
      }
      draw();
    }
    requestAnimationFrame(update);
  }

  function draw() {
    drawGrid();
    // Draw current piece
    for (let y=0;y<piece.shape.length;y++) for (let x=0;x<piece.shape[y].length;x++) {
      if (piece.shape[y][x]) drawBlock(piece.x + x, piece.y + y, COLORS[piece.type]);
    }
  }

  function drop() {
    if (!collides(piece,0,1)) {
      piece.y++;
    } else {
      merge(piece);
      const c = clearLines();
      if (c>0) {
        lines += c;
        score += [0,40,100,300,1200][c] * level;
        level = 1 + Math.floor(lines/10);
        renderHUD();
      }
      piece = randomPiece();
      if (collides(piece,0,0)) {
        // Game over: reset grid
        alert('!סיום משחק\nהניקוד שלך: ' + score);
        restart();
      }
    }
  }

  function move(dir) {
    if (!collides(piece, dir, 0)) piece.x += dir;
  }

  function rotatePiece() {
    const r = rotate(piece.shape);
    // wall kicks בסיסיים
    if (!collides(piece,0,0,r)) piece.shape = r;
    else if (!collides(piece,-1,0,r)) { piece.x -= 1; piece.shape = r; }
    else if (!collides(piece,1,0,r)) { piece.x += 1; piece.shape = r; }
  }

  function hardDropStep() {
    if (!collides(piece,0,1)) { piece.y++; return true; }
    return false;
  }
  function hardDrop() {
    let moved = false;
    while (hardDropStep()) moved = true;
    if (!moved) return;
    drop();
  }

  function renderHUD() {
    scoreEl.textContent = score;
    linesEl.textContent = lines;
    levelEl.textContent = level;
  }

  // קלט מקלדת
  window.addEventListener('keydown', (e) => {
    if (['ArrowLeft','ArrowRight','ArrowDown','ArrowUp','Space','KeyP'].includes(e.code)) e.preventDefault();
    switch (e.code) {
      case 'ArrowLeft': move(-1); break;
      case 'ArrowRight': move(1); break;
      case 'ArrowDown': drop(); break;
      case 'ArrowUp': rotatePiece(); break;
      case 'Space': hardDrop(); break;
      case 'KeyP': togglePause(); break;
    }
  });

  // כפתורים למסך מגע
  btnL.addEventListener('click', () => move(-1));
  btnR.addEventListener('click', () => move(1));
  btnRot.addEventListener('click', rotatePiece);
  btnD.addEventListener('click', drop);
  btnPause.addEventListener('click', togglePause);
  btnRestart.addEventListener('click', restart);

  function togglePause() { paused = !paused; btnPause.textContent = paused ? 'המשך' : 'השהה/המשך'; }
  function restart() {
    grid = Array.from({length: ROWS}, emptyRow);
    score = 0; lines = 0; level = 1;
    piece = randomPiece();
    renderHUD();
  }

  // התאמת רזולוציה חכמה (High-DPI)
  function resizeCanvas() {
    const scale = Math.min(window.devicePixelRatio || 1, 2);
    canvas.style.width = '100%';
    const rect = canvas.getBoundingClientRect();
    canvas.width = Math.round(rect.width * scale);
    const block = Math.floor(canvas.width / COLS);
    canvas.width = block * COLS;
    canvas.height = block * ROWS;
  }
  window.addEventListener('resize', () => { resizeCanvas(); draw(); });

  resizeCanvas();
  renderHUD();
  requestAnimationFrame(update);
})();
